
#ifndef ASS5_ACCOUNT_H
#define ASS5_ACCOUNT_H

class Account {
public:
private:
};
#endif // ASS5_ACCOUNT_H
